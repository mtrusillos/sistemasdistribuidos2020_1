﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace platonWSREST.Dominio
{
    [DataContract]
    public class Secciones
    {
        [DataMember]
        public int id { get; set; }

        [DataMember]
        public string codseccion { get; set; }

        [DataMember]
        public string desseccion { get; set; }

        [DataMember]
        public string campus { get; set; }

        [DataMember]
        public string estado { get; set; }
    }
}