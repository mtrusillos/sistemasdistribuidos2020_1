﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace platonWSREST.Dominio
{
    [DataContract]
    public class Ciclos
    {
        [DataMember]
        public int id { get; set; }
        
        [DataMember]
        public string codciclo { get; set; }
        
        [DataMember]
        public string desciclo { get; set; }

        [DataMember]        
        public DateTime desde { get; set; }
        
        [DataMember]
        public DateTime hasta { get; set; }

        [DataMember]
        public string estado { get; set; }
    }
}