﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Runtime.Serialization;
using System.Web;

namespace platonWSREST.Dominio
{
    [DataContract]
    public class Cursos
    {
        [DataMember]
        public int id { get; set; }

        [DataMember]
        public string codcurso { get; set; }

        [DataMember]
        public string descurso { get; set; }

        [DataMember]
        public int nivel { get; set; }

        [DataMember]
        public int malla { get; set; }

        [DataMember]
        public string estado { get; set; }
    }
}