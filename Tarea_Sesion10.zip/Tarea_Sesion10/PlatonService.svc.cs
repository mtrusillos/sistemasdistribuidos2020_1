﻿using platonWSREST.Model;
using platonWSREST.Dominio;
using System.Collections.Generic;
using System.Data.Entity;
using System.Linq;

namespace platonWSREST
{
    [System.ServiceModel.ServiceBehavior(IncludeExceptionDetailInFaults = true)]
    public class PlatonService : IPlatonService
    {
        private platonEntities db = new platonEntities();

        /*      HORARIOS      */
        public horario ModificarHorario(horario horarioAModificar)
        {
            db.Entry(horarioAModificar).State = EntityState.Modified;
            db.SaveChanges();
            horario horario = ObtenerHorario(horarioAModificar.codhorario);
            return horario;
        }

        public horario ObtenerHorario(string codhorario)
        {
            var query = from horario in db.horarios.Where(x => (x.codhorario == codhorario))
                        select horario;
            horario resultado = query.FirstOrDefault();
            return resultado;

        }
        public horario CrearHorario(horario horarioACrear)
        {
            db.horarios.Add(horarioACrear);
            db.SaveChanges();
            horario horario = ObtenerHorario(horarioACrear.codhorario);
            return horario;
        }

        public void EliminarHorario(string codhorario)
        {
            horario horario = ObtenerHorario(codhorario);
            if (horario != null)
            {
                db.horarios.Remove(horario);
                db.SaveChanges();
            }
        }
        public List<Horarios> ListarHorarios()
        {
            var query = from a in db.horarios
                        join b in db.cicloes on a.codciclo equals b.codciclo
                        join c in db.cursoes on a.codcurso equals c.codcurso
                        join d in db.seccions on a.codseccion equals d.codseccion
                        select new Horarios
                        {
                            id = a.id,
                            codhorario = a.codhorario,
                            codciclo = a.codciclo,
                            desciclo = b.desciclo,
                            codcurso = a.codcurso,
                            descurso = c.descurso,
                            codseccion = a.codseccion,
                            desseccion = d.desseccion,
                            finicio = (System.DateTime)a.finicio,
                            ffinal = (System.DateTime)a.ffinal,
                            estado = a.estado
                        };
            return query.ToList();
        }

        /*      CICLOS      */
        public ciclo ModificarCiclo(ciclo cicloAModificar)
        {
            db.Entry(cicloAModificar).State = EntityState.Modified;
            db.SaveChanges();
            ciclo ciclo = ObtenerCiclo(cicloAModificar.codciclo);
            return ciclo;
        }

        public ciclo ObtenerCiclo(string codciclo)
        {
            var query = from ciclo in db.cicloes.Where(x => (x.codciclo == codciclo))
                        select ciclo;
            ciclo resultado = query.FirstOrDefault();
            return resultado;

        }
        public ciclo CrearCiclo(ciclo cicloACrear)
        {
            db.cicloes.Add(cicloACrear);
            db.SaveChanges();
            ciclo ciclo = ObtenerCiclo(cicloACrear.codciclo);
            return ciclo;
        }

        public void EliminarCiclo(string codciclo)
        {
            ciclo ciclo = ObtenerCiclo(codciclo);
            if (ciclo != null)
            {
                db.cicloes.Remove(ciclo);
                db.SaveChanges();
            }
        }

        public List<ciclo> Listarciclos()
        {
            return db.cicloes.ToList();
        }

        /*      CURSOS      */
        public curso ModificarCurso(curso cursoAModificar)
        {
            db.Entry(cursoAModificar).State = EntityState.Modified;
            db.SaveChanges();
            curso curso = ObtenerCurso(cursoAModificar.codcurso);
            return curso;
        }

        public curso ObtenerCurso(string codcurso)
        {
            var query = from curso in db.cursoes.Where(x => (x.codcurso == codcurso))
                        select curso;
            curso resultado = query.FirstOrDefault();
            return resultado;

        }
        public curso CrearCurso(curso cursoACrear)
        {
            db.cursoes.Add(cursoACrear);
            db.SaveChanges();
            curso curso = ObtenerCurso(cursoACrear.codcurso);
            return curso;
        }

        public void EliminarCurso(string codcurso)
        {
            curso curso = ObtenerCurso(codcurso);
            if (curso != null)
            {
                db.cursoes.Remove(curso);
                db.SaveChanges();
            }
        }

        public List<curso> ListarCursos()
        {
            return db.cursoes.ToList();
        }

        /*     SECCIONES      */
        public seccion ModificarSeccion(seccion seccionAModificar)
        {
            db.Entry(seccionAModificar).State = EntityState.Modified;
            db.SaveChanges();
            seccion seccion = ObtenerSeccion(seccionAModificar.codseccion);
            return seccion;
        }

        public seccion ObtenerSeccion(string codseccion)
        {
            var query = from seccion in db.seccions.Where(x => (x.codseccion == codseccion))
                        select seccion;
            seccion resultado = query.FirstOrDefault();
            return resultado;

        }
        public seccion CrearSeccion(seccion seccionACrear)
        {
            db.seccions.Add(seccionACrear);
            db.SaveChanges();
            seccion seccion = ObtenerSeccion(seccionACrear.codseccion);
            return seccion;
        }

        public void EliminarSeccion(string codseccion)
        {
            seccion seccion = ObtenerSeccion(codseccion);
            if (seccion != null)
            {
                db.seccions.Remove(seccion);
                db.SaveChanges();
            }
        }
        public List<seccion> ListarSecciones()
        {
            return db.seccions.ToList();
        }    }
}