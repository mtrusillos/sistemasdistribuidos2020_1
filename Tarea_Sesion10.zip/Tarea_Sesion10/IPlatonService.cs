﻿using platonWSREST.Dominio;
using platonWSREST.Model;
using System.Collections.Generic;
using System.ServiceModel;
using System.ServiceModel.Web;

namespace platonWSREST
{
    [ServiceContract]
    public interface IPlatonService
    {
        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "horarios", ResponseFormat = WebMessageFormat.Json)]
        horario CrearHorario(horario horarioACrear);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "horarios/{codhorario}", ResponseFormat = WebMessageFormat.Json)]
        horario ObtenerHorario(string codhorario);

        [OperationContract]
        [WebInvoke(Method = "PUT", UriTemplate = "horarios", ResponseFormat = WebMessageFormat.Json)]
        horario ModificarHorario(horario horarioAModificar);

        [OperationContract]
        [WebInvoke(Method = "DELETE", UriTemplate = "horarios/{codhorario}", ResponseFormat = WebMessageFormat.Json)]
        void EliminarHorario(string codhorario);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "Horarios", ResponseFormat = WebMessageFormat.Json)]
        List<Horarios> ListarHorarios();


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "ciclos", ResponseFormat = WebMessageFormat.Json)]
        ciclo CrearCiclo(ciclo cicloACrear);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "ciclos/{codciclo}", ResponseFormat = WebMessageFormat.Json)]
        ciclo ObtenerCiclo(string codciclo);

        [OperationContract]
        [WebInvoke(Method = "PUT", UriTemplate = "ciclos", ResponseFormat = WebMessageFormat.Json)]
        ciclo ModificarCiclo(ciclo cicloAModificar);

        [OperationContract]
        [WebInvoke(Method = "DELETE", UriTemplate = "ciclos/{codciclo}", ResponseFormat = WebMessageFormat.Json)]
        void EliminarCiclo(string codciclo);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "ciclos", ResponseFormat = WebMessageFormat.Json)]
        List<ciclo> Listarciclos();


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "cursos", ResponseFormat = WebMessageFormat.Json)]
        curso CrearCurso(curso cicloACrear);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "cursos/{codcurso}", ResponseFormat = WebMessageFormat.Json)]
        curso ObtenerCurso(string codcurso);

        [OperationContract]
        [WebInvoke(Method = "PUT", UriTemplate = "cursos", ResponseFormat = WebMessageFormat.Json)]
        curso ModificarCurso(curso cursoAModificar);

        [OperationContract]
        [WebInvoke(Method = "DELETE", UriTemplate = "cursos/{codcurso}", ResponseFormat = WebMessageFormat.Json)]
        void EliminarCurso(string codcurso);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "cursos", ResponseFormat = WebMessageFormat.Json)]
        List<curso> ListarCursos();


        [OperationContract]
        [WebInvoke(Method = "POST", UriTemplate = "secciones", ResponseFormat = WebMessageFormat.Json)]
        seccion CrearSeccion(seccion seccionACrear);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "secciones/{codseccion}", ResponseFormat = WebMessageFormat.Json)]
        seccion ObtenerSeccion(string codseccion);

        [OperationContract]
        [WebInvoke(Method = "PUT", UriTemplate = "secciones", ResponseFormat = WebMessageFormat.Json)]
        seccion ModificarSeccion(seccion seccionAModificar);

        [OperationContract]
        [WebInvoke(Method = "DELETE", UriTemplate = "secciones/{codseccion}", ResponseFormat = WebMessageFormat.Json)]
        void EliminarSeccion(string codseccion);

        [OperationContract]
        [WebInvoke(Method = "GET", UriTemplate = "secciones", ResponseFormat = WebMessageFormat.Json)]
        List<seccion> ListarSecciones();
    }
}